<?php
$conn=mysqli_connect("localhost", "root", "", "dhis") or die(mysql_errno('ERROR CONNECTING'));
$value='';

?>
<!DOCTYPE html>
<html>
<head>
	<title>DHIS 2</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body style="margin-left: 50px">
	<h3>
		<center>
			POSTING TO DHIS 2 USING API
		</center>
	</h3>
<form action="" method="POST" style="margin-top: 100px">
	<table>
		<tr>
			<td>NAME</td>
			<td>VALUE</td>
		</tr>
	    <tbody>
			<?php
			$q = $conn->query("SELECT * FROM dataset_values"); 
			$i=0;                   
	        while($r = $q->fetch_assoc())
	        {
	        	echo 
	        	'<tr>
	        	<input type="hidden" name="element_id" value="'.$r['element_id'].'" readonly>
	        	<td><input type="text" name="name" value="'.$r['name'].'" readonly></td>
	        	<td><input type="text" name="value'.$i++.'" value="'.$r['value'].'"></td>
	            </tr>';
	        }
	        ?>
	         
		</tbody>
	</table><br/>
	<button name="save" type="submit">SAVE</button>
</form>	
<?php
if (isset($_POST['save'])) {
	$element_id = $_POST['element_id'];
	$name = $_POST['name'];
	$value0 =$_POST['value0'];
	$value1 =$_POST['value1'];
	$value2 =$_POST['value2'];


	$a=$conn->query("UPDATE dataset_values SET value='$value0' WHERE element_id = 'CgN7WpWvOJW' ");
	$a=$conn->query("UPDATE dataset_values SET value='$value1' WHERE element_id = 'GvfD5dtg9eQ' ");
	$a=$conn->query("UPDATE dataset_values SET value='$value2' WHERE element_id = 'lfMEJvS1vhu' ");
	echo '<script>alert("SAVED"); window.location="index.php";</script>';
}
?>		


<?php
if (isset($_POST['dhis'])) {
	$period=201912;
	$a=$conn->query("SELECT * FROM dataset_values") or die(mysqli_connect_errno());
			
			while ($row = $a->fetch_assoc()) {
				
				$element_id=$row['element_id'];
				$value=$row['value'];
				
				try {	
				
				$initialize = curl_init();
				curl_setopt($initialize, CURLOPT_URL,"http://your-server-url/api/32/dataValues?de=$element_id&pe=$period&ou=V5XvX1wr1kF");
				curl_setopt($initialize, CURLOPT_POST, 1);
				curl_setopt($initialize, CURLOPT_USERPWD, "admin:district");//user your username:password
				curl_setopt($initialize, CURLOPT_POSTFIELDS,"value=$value");
				curl_setopt($initialize, CURLOPT_RETURNTRANSFER, true);
				$server_output = curl_exec ($initialize);
				curl_close ($initialize);				
				
			}catch (Exception $e) {
				echo 'ERROR CAUGHT: ',  $e->getMessage(), "\n";
			}
		}
				if ($initialize) { 
					echo 'DATA EXPORTED TO DHIS2'; 
			} else { 
				echo 'EXPORT FAILED';
			}
				echo '<script>alert("EXPORTED TO DHIS2"); window.location="index.php";</script>';
			}
?>
<table border="1" style="margin-top: 20px">
		<tr>
			<td>NAME</td>
			<td>VALUE</td>
		</tr>

	    <tbody>
			<?php
			$q = $conn->query("SELECT * FROM dataset_values");                    
	        while($r = $q->fetch_assoc())
	        {
	        	echo 
	        	'<tr>
	        	<td><input type="text" value="'.$r['name'].'" readonly></td>
	        	<td><input type="text" value="'.$r['value'].'" readonly></td>
	            </tr>';
	        }
	        ?>
	         
		</tbody>
	</table><p></p>
	<form action="" method="POST">
	    <button name="dhis" type="submit">POST TO DHIS2</button>
    </form>	
</body>
</html>